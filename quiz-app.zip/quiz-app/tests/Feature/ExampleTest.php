<?php

namespace Tests\Feature;

use App\Models\User;
use Tests\TestCase;

class ExampleTest extends TestCase
{
    public function test_guests_are_redirected_to_the_login_screen(): void
    {
        $response = $this->get('/');

        $response->assertRedirect(route('login'));
    }

    public function test_authenticated_users_are_redirected_to_category_selection(): void
    {
        $user = new User([
            'name' => 'Test User',
            'email' => 'test@example.com',
            'password' => 'secret',
        ]);

        $response = $this->be($user)->get('/');

        $response->assertRedirect(route('quiz.categories'));
    }

    public function test_signup_screen_is_available(): void
    {
        $response = $this->get(route('register'));

        $response->assertOk();
    }
}
