# 🎯 Online Quiz

A trivia quiz application built with Laravel. Test your knowledge across various categories!

---

## 🚀 Features

* User Authentication (Signup / Login)
* Select from multiple trivia categories
* Play a 50-question multiple-choice quiz with a **30-second per-question timer**
* View final score, percentage, and result (Pass/Fail)
* Replay quiz or choose a different category
* API-based dynamic question fetching

---

## 🛠️ Tech Stack

* PHP (Laravel Framework)
* SQLite (Default) / MySQL
* Blade (Frontend) with custom CSS styling
* Laravel HTTP Client (Guzzle under the hood)

---

## 🔌 Third-Party API Integration

This application integrates with an external Trivia API.

* Base URL and API key are configured via `.env`
* API calls are handled through a dedicated service: `App\Services\TriviaApiClient`
* Centralized request handling with proper error management
* Clean separation between API layer and business logic

---

## 📂 Project Structure Highlights

* `App\Services\TriviaApiClient` → Handles all external API communication
* `App\Services\Quiz\QuizService` → Contains quiz business logic
* `App\Enums\QuizCategory` → Static category definitions
* `config/services.php` → Third-party API configuration
* `config/quiz.php` → Application-specific configurations

---

## ⚙️ Configuration

Add the following to your `.env` file:

```env
TRIVIA_API_URL=https://the-trivia-api.com/v2/
TRIVIA_API_KEY=
QUIZ_QUESTION_COUNT=50
```

---

## 🧠 Categories Implementation

For quiz categories, a custom Enum file (`App\Enums\QuizCategory`) is used instead of fetching them dynamically from the API.

### Reason:

* The Trivia API endpoint for fetching categories requires an API key or subscription.
* To avoid dependency on restricted endpoints, categories are defined statically within the application.

### Note:

* Other API endpoints (such as fetching random questions based on the selected category) are publicly accessible and are used successfully in this application.
* This approach ensures smooth functionality without requiring paid API access while still leveraging dynamic question data.

---

## ▶️ Setup Instructions

1. Clone the repository:

```bash
git clone https://github.com/sreeshma7978/quiz-app
```

2. Navigate to project:

```bash
cd online-quiz
```

3. Install dependencies:

```bash
composer install
npm install
npm run build
```

4. Environment setup:

```bash
cp .env.example .env
```

5. Configure:

* Database credentials (defaults to SQLite)
* API URL (optional)

6. Generate application key:

```bash
php artisan key:generate
```

7. Run migrations:

```bash
php artisan migrate
```

8. Clear and cache config (important):

```bash
php artisan config:clear
php artisan config:cache
```

9. Start the server:

```bash
php artisan serve
```

---

## 🧪 Running the Application

* Visit: http://127.0.0.1:8000
* Register/Login
* Choose a category
* Start the quiz

---

## 🔍 Debugging Tips

* If API is not working:

```bash
php artisan config:clear
```

* Check config values:
* Ensure `.env` values are correct
* Restart server if needed

---

## ⚡ Future Improvements

* Admin panel for managing quizzes
* Leaderboard system
* Difficulty levels
* API response caching
* Unit & feature testing

---

## 💡 Design Decisions

* Used Service Layer for API integration
* Separated business logic from controllers
* Used config-driven architecture for flexibility
* Implemented rate limiting for security
* Used Enum for category management to avoid restricted API dependency

---

## 📌 Notes

* Internet connection is required for API calls
* Some API endpoints require subscription (not used in this project)

* To reduce the ZIP file size, the following directories are excluded:

- /vendor
- /node_modules
- /storage/logs
- /storage/framework/cache
- /storage/framework/sessions
- /storage/framework/views

After extracting the project, run the following commands:

composer install  
npm install
---

## 🙌 Conclusion

This project demonstrates:

* Clean and scalable Laravel architecture
* Efficient third-party API integration
* Maintainable and structured code design
