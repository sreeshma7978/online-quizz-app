<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?php echo e($title ?? 'Online Quiz'); ?></title>
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=dm-sans:400,500,700|space-grotesk:400,500,700" rel="stylesheet" />
        <link rel="stylesheet" href="<?php echo e(asset('css/quiz.css')); ?>">
        <script src="https://code.jquery.com/jquery-3.7.1.min.js" crossorigin="anonymous"></script>
        <script src="<?php echo e(asset('js/quiz.js')); ?>" defer></script>
        <?php if(file_exists(public_path('build/manifest.json')) || file_exists(public_path('hot'))): ?>
            <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
        <?php endif; ?>
    </head>
    <body class="<?php echo e(trim((auth()->check() ? 'quiz-authenticated' : 'quiz-guest').' '.($bodyClass ?? ''))); ?>">
        <main class="quiz-shell">
            <div class="quiz-stage">
                <?php if(auth()->guard()->check()): ?>
                    <div class="quiz-topbar">
                        <div class="quiz-topbar-copy">
                            <p class="quiz-topbar-title">Online Quiz</p>
                            <p class="quiz-topbar-subtitle">Welcome back, <?php echo e(auth()->user()->name); ?></p>
                        </div>
                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="quiz-topbar-btn">Logout</button>
                        </form>
                    </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                    <div class="quiz-alert">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p><?php echo e($error); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>

                <?php echo e($slot); ?>

            </div>
        </main>
    </body>
</html>
<?php /**PATH /home/user/Documents/Q/quiz-app/resources/views/components/layouts/app.blade.php ENDPATH**/ ?>