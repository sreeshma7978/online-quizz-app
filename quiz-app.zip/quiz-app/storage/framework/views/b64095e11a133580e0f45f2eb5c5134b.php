<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'Online Quiz - Login']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Online Quiz - Login')]); ?>
    <section class="quiz-auth-page">
        <div class="quiz-login-wrap">
            <!-- <h1 class="quiz-login-title">Online Quiz - Login</h1> -->

            <div class="quiz-login-card">
                <div class="quiz-login-card-header">
                    <h2>Login</h2>
                </div>

                <div class="quiz-login-card-body">
                    <form method="POST" action="<?php echo e(route('login.attempt')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="quiz-field">
                            <label for="email">Username</label>
                            <input
                                id="email"
                                name="email"
                                type="email"
                                value="<?php echo e(old('email')); ?>"
                                required
                                autofocus
                                class="quiz-input-line"
                                placeholder="Username"
                            >
                        </div>

                        <div class="quiz-field">
                            <label for="password">Password</label>
                            <input
                                id="password"
                                name="password"
                                type="password"
                                required
                                class="quiz-input-line"
                                placeholder="Password"
                            >
                        </div>

                        <span class="quiz-forgot">Forgot Password?</span>

                        <button type="submit" class="quiz-primary-btn">Login</button>
                    </form>

                    <div class="quiz-auth-footer">
                        Not a member?
                        <a href="<?php echo e(route('register')); ?>">Signup</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH /home/user/Documents/Q/quiz-app/resources/views/auth/login.blade.php ENDPATH**/ ?>