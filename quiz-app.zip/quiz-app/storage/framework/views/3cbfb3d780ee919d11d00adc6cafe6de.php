<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'Online Quiz - Signup','bodyClass' => 'quiz-signup-background']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Online Quiz - Signup'),'bodyClass' => 'quiz-signup-background']); ?>
    <section class="quiz-signup-page">
        <div class="quiz-signup-wrap">
            <h1 class="quiz-signup-title">Signup</h1>

            <div class="quiz-signup-center">
                <div class="quiz-signup-card">
                    <h2>Create an account</h2>

                    <form method="POST" action="<?php echo e(route('register.store')); ?>" class="quiz-signup-form">
                        <?php echo csrf_field(); ?>
                        <div class="quiz-field quiz-field-icon">
                            <label for="name">
                                <span class="quiz-field-glyph quiz-field-glyph-neutral" aria-hidden="true">
                                    <svg viewBox="0 0 16 16" class="quiz-field-icon-svg">
                                        <path d="M8 8.1a2.8 2.8 0 1 0 0-5.6 2.8 2.8 0 0 0 0 5.6Z" fill="currentColor"/>
                                        <path d="M2.4 13.3c0-2.2 2.3-3.8 5.6-3.8s5.6 1.6 5.6 3.8v.4H2.4v-.4Z" fill="currentColor"/>
                                    </svg>
                                </span>
                                Username or Email
                            </label>
                            <div class="quiz-field-input-wrap">
                                <input id="name" name="name" type="text" value="<?php echo e(old('name')); ?>" required autofocus class="quiz-input-line">
                            </div>
                        </div>

                        <div class="quiz-field quiz-field-icon">
                            <label for="email">
                                <span class="quiz-field-glyph quiz-field-glyph-neutral" aria-hidden="true">
                                    <svg viewBox="0 0 16 16" class="quiz-field-icon-svg">
                                        <rect x="2.2" y="4" width="11.6" height="8" rx="1.2" fill="none" stroke="currentColor" stroke-width="1.4"/>
                                        <path d="m3.4 5 4.6 3.5L12.6 5" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </span>
                                Email
                            </label>
                            <div class="quiz-field-input-wrap">
                                <input id="email" name="email" type="email" value="<?php echo e(old('email')); ?>" required class="quiz-input-line quiz-input-line-success">
                            </div>
                        </div>

                        <div class="quiz-field quiz-field-icon">
                            <label for="password">
                                <span class="quiz-field-glyph quiz-field-glyph-neutral" aria-hidden="true">
                                    <svg viewBox="0 0 16 16" class="quiz-field-icon-svg">
                                        <rect x="3.3" y="7" width="9.4" height="6.7" rx="1.2" fill="none" stroke="currentColor" stroke-width="1.4"/>
                                        <path d="M5.4 7V5.7a2.6 2.6 0 0 1 5.2 0V7" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/>
                                    </svg>
                                </span>
                                New password
                            </label>
                            <div class="quiz-field-input-wrap">
                                <input id="password" name="password" type="password" required class="quiz-input-line">
                            </div>
                        </div>

                        <div class="quiz-field quiz-field-icon">
                            <label for="password_confirmation">
                                <span class="quiz-field-glyph quiz-field-glyph-neutral" aria-hidden="true">
                                    <svg viewBox="0 0 16 16" class="quiz-field-icon-svg">
                                        <rect x="3.3" y="7" width="9.4" height="6.7" rx="1.2" fill="none" stroke="currentColor" stroke-width="1.4"/>
                                        <path d="M5.4 7V5.7a2.6 2.6 0 0 1 5.2 0V7" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/>
                                    </svg>
                                </span>
                                New password (repeat)
                            </label>
                            <div class="quiz-field-input-wrap">
                                <input id="password_confirmation" name="password_confirmation" type="password" required class="quiz-input-line">
                            </div>
                        </div>

                        <button type="submit" class="quiz-signup-btn">
                            Create Account
                        </button>
                    </form>

                    <p class="quiz-signup-footer">
                        Already have an account?
                        <a href="<?php echo e(route('login')); ?>">Login</a>
                    </p>
                </div>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH /home/user/Documents/projectNew/quiz-app/resources/views/auth/register.blade.php ENDPATH**/ ?>