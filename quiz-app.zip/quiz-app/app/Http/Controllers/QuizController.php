<?php

namespace App\Http\Controllers;

use App\Http\Requests\AnswerQuizRequest;
use App\Http\Requests\StartQuizRequest;
use App\Services\Quiz\QuizException;
use App\Services\Quiz\QuizService;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;

class QuizController extends Controller
{
    public function __construct(
        private readonly QuizService $quizService,
    ) {
    }

    public function categories(): View
    {
        return view('quiz.categories', [
            'categories' => $this->quizService->categories(),
        ]);
    }

    public function start(StartQuizRequest $request): RedirectResponse
    {
        try {
            $this->quizService->start($request->category());
        } catch (QuizException $exception) {
            return redirect()
                ->route('quiz.categories')
                ->withErrors([
                    'quiz' => $exception->getMessage(),
                ]);
        }

        return redirect()->route('quiz.play');
    }

    public function play(): View|RedirectResponse
    {
        if (! $this->quizService->isActive()) {
            return redirect()->route('quiz.categories');
        }

        if ($this->quizService->hasCompleted()) {
            return redirect()->route('quiz.results');
        }

        return view('quiz.play', $this->quizService->currentQuestion());
    }

    public function answer(AnswerQuizRequest $request): RedirectResponse
    {
        if (! $this->quizService->isActive()) {
            return redirect()->route('quiz.categories');
        }

        $this->quizService->answer($request->answer());

        return $this->quizService->hasCompleted()
            ? redirect()->route('quiz.results')
            : redirect()->route('quiz.play');
    }

    public function results(): View|RedirectResponse
    {
        if (! $this->quizService->isActive()) {
            return redirect()->route('quiz.categories');
        }

        if (! $this->quizService->hasCompleted()) {
            return redirect()->route('quiz.play');
        }

        return view('quiz.results', $this->quizService->results());
    }

    public function reset(): RedirectResponse
    {
        $this->quizService->reset();

        return redirect()->route('quiz.categories');
    }
}
