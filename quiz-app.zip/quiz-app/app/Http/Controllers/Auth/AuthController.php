<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\LoginRequest;
use App\Http\Requests\RegisterRequest;
use App\Services\Auth\AuthService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class AuthController extends Controller
{
    public function __construct(
        private readonly AuthService $authService,
    ) {
    }

    public function showLogin(): View
    {
        return view('auth.login');
    }

    public function login(LoginRequest $request): RedirectResponse
    {
        
        $result = $this->authService->attemptLogin(
            $request->credentials(),
            $request->remember(),
            $request->session(),
        );

        if (! $result->successful) {
            return back()
                ->withInput($request->only('email'))
                ->withErrors([
                    $result->errorField => $result->errorMessage,
                ]);
        }

        return redirect()->route('quiz.categories');
    }

    public function showRegister(): View
    {
        return view('auth.register');
    }

    public function register(RegisterRequest $request): RedirectResponse
    {
        $this->authService->register(
            $request->registrationData(),
            $request->session(),
        );

        return redirect()->route('quiz.categories');
    }

    public function logout(Request $request): RedirectResponse
    {
        $this->authService->logout($request->session());

        return redirect()->route('login');
    }
}
