<?php

namespace App\Http\Requests;

use App\Enums\QuizCategory;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StartQuizRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'category' => ['required', 'string', Rule::in(QuizCategory::values())],
        ];
    }

    public function category(): QuizCategory
    {
        return QuizCategory::from($this->validated('category'));
    }
}
