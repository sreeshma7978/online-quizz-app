<?php

namespace App\Enums;

enum QuizOutcome: string
{
    case Winner = 'Winner';
    case Better = 'Better';
    case Failed = 'Failed';

    public static function fromPercentage(int $percentage): self
    {
        return match (true) {
            $percentage >= 60 => self::Winner,
            $percentage >= 40 => self::Better,
            default => self::Failed,
        };
    }

    public function label(): string
    {
        return $this->value;
    }
}
