<?php

namespace App\Enums;

enum QuizCategory: string
{
    case ArtsAndLiterature = 'arts_and_literature';
    case History = 'history';
    case FilmAndTv = 'film_and_tv';
    case Geography = 'geography';
    case FoodAndDrink = 'food_and_drink';
    case GeneralKnowledge = 'general_knowledge';
    case Music = 'music';
    case Science = 'science';
    case SocietyAndCulture = 'society_and_culture';
    case SportAndLeisure = 'sport_and_leisure';
    case Television = 'television';
    case VideoGames = 'video_games';
    case World = 'world';
    case Mythology = 'mythology';
    case Comics = 'comics';
    case AnimeAndManga = 'anime_and_manga';
    case CartoonAndAnimations = 'cartoon_and_animations';
    case Gadgets = 'gadgets';

    public function label(): string
    {
        return match ($this) {
            self::ArtsAndLiterature => 'Arts & Literature',
            self::History => 'History',
            self::FilmAndTv => 'Film & TV',
            self::Geography => 'Geography',
            self::FoodAndDrink => 'Food & Drink',
            self::GeneralKnowledge => 'General Knowledge',
            self::Music => 'Music',
            self::Science => 'Science',
            self::SocietyAndCulture => 'Society & Culture',
            self::SportAndLeisure => 'Sport & Leisure',
            self::Television => 'Television',
            self::VideoGames => 'Video Games',
            self::World => 'World',
            self::Mythology => 'Mythology',
            self::Comics => 'Comics',
            self::AnimeAndManga => 'Anime & Manga',
            self::CartoonAndAnimations => 'Cartoon & Animations',
            self::Gadgets => 'Gadgets',
        };
    }

    /**
     * @return array<string, string>
     */
    public static function options(): array
    {
        $options = [];

        foreach (self::cases() as $category) {
            $options[$category->value] = $category->label();
        }

        return $options;
    }

    /**
     * @return list<string>
     */
    public static function values(): array
    {
        return array_map(
            static fn (self $category): string => $category->value,
            self::cases(),
        );
    }
}
