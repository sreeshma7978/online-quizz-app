<?php

namespace App\Services\Auth;

use App\Models\User;
use Illuminate\Contracts\Auth\Factory as AuthFactory;
use Illuminate\Contracts\Session\Session;
use Illuminate\Support\Facades\Hash;

class AuthService
{
    public function __construct(
        private readonly AuthFactory $auth,
    ) {
    }

    /**
     * @param  array{email: string, password: string}  $credentials
     */
    public function attemptLogin(array $credentials, bool $remember, Session $session): LoginResult
    {
        $user = User::query()->where('email', $credentials['email'])->first();

        if (! $user) {
            return LoginResult::failure('email', 'This email address is not registered.');
        }

        if (! Hash::check($credentials['password'], $user->password)) {
            return LoginResult::failure('password', 'The password you entered is incorrect.');
        }

        $this->auth->guard()->login($user, $remember);

        $session->regenerate();

        return LoginResult::success();
    }

    /**
     * @param  array{name: string, email: string, password: string}  $attributes
     */
    public function register(array $attributes, Session $session): User
    {
        $user = User::create([
            'name' => $attributes['name'],
            'email' => $attributes['email'],
            'password' => Hash::make($attributes['password']),
        ]);

        $this->auth->guard()->login($user);
        $session->regenerate();

        return $user;
    }

    public function logout(Session $session): void
    {
        $this->auth->guard()->logout();
        $session->invalidate();
        $session->regenerateToken();
    }
}
