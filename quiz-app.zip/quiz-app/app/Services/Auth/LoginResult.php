<?php

namespace App\Services\Auth;

final class LoginResult
{
    private function __construct(
        public readonly bool $successful,
        public readonly ?string $errorField = null,
        public readonly ?string $errorMessage = null,
    ) {
    }

    public static function success(): self
    {
        return new self(true);
    }

    public static function failure(string $errorField, string $errorMessage): self
    {
        return new self(false, $errorField, $errorMessage);
    }
}
