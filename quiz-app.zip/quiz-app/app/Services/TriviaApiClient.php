<?php

namespace App\Services;

use Illuminate\Http\Client\PendingRequest;
use Illuminate\Http\Client\RequestException;
use Illuminate\Support\Facades\Http;
use RuntimeException;

class TriviaApiClient
{
    public function __construct(
        private readonly ?string $apiKey = null,
        private readonly ?string $baseUrl = null,
    ) {
    }

    private function client(): PendingRequest
    {
        $client = Http::acceptJson()
            ->contentType('application/json')
            ->baseUrl(rtrim($this->baseUrl ?? config('services.trivia.base_url'), '/'))
            ->timeout(15);

        $apiKey = $this->apiKey ?? config('services.trivia.key');

        if (! empty($apiKey) && $apiKey !== '.') {
            $client = $client->withHeader('X-API-Key', $apiKey);
        }

        return $client;
    }

    private function request(string $method, string $uri, array $options = []): ?array
    {
        try {
            $response = $this->client()->send($method, ltrim($uri, '/'), $options)->throw();

            if ($response->status() === 204) {
                return null;
            }

            return $response->json();
        } catch (RequestException $exception) {
            $message = $exception->response?->json('message')
                ?? $exception->response?->body()
                ?? $exception->getMessage();

            throw new RuntimeException('Trivia API request failed: '.$message, $exception->getCode(), $exception);
        } catch (\Throwable $exception) {
            throw new RuntimeException('Trivia API request failed: '.$exception->getMessage(), $exception->getCode(), $exception);
        }
    }

    public function getRandomQuestions(array $params = []): array
    {
        return $this->request('GET', '/questions', ['query' => $params]) ?? [];
    }

   
}
