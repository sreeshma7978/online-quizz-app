<?php

namespace App\Services\Quiz;

use App\Enums\QuizCategory;
use App\Enums\QuizOutcome;
use App\Services\TriviaApiClient;
use Illuminate\Support\Arr;
use Illuminate\Support\Collection;
use RuntimeException;

class QuizService
{
    private const SESSION_KEY = 'quiz.session';

    public function __construct(
        private readonly TriviaApiClient $triviaApiClient,
    ) {
    }

    /**
     * @return array<string, string>
     */
    public function categories(): array
    {
        return QuizCategory::options();
    }

    public function start(QuizCategory $category): void
    {
        $count = config('quiz.question_count') ?? 5;
        try {
            $questions = $this->buildQuestions(
                $this->triviaApiClient->getRandomQuestions([
                    'limit' => $count,
                    'categories' => $category->value,
                    'types' => 'text_choice',
                ])
            );
        } catch (RuntimeException $exception) {
            throw new QuizException('We could not load trivia questions right now. Please try again in a moment.', previous: $exception);
        }

        if ($questions->isEmpty()) {
            throw new QuizException('No text-choice questions were returned for that category. Please pick another one.');
        }

        session()->put(self::SESSION_KEY, [
            'category' => $category->value,
            'category_label' => $category->label(),
            'questions' => $questions->all(),
            'current_index' => 0,
            'started_at' => now()->toIso8601String(),
        ]);
    }

    /**
     * @return array<string, mixed>|null
     */
    public function currentQuestion(): ?array
    {
        $quiz = $this->quiz();

        if (! $quiz) {
            return null;
        }

        $currentIndex = $quiz['current_index'];
        $questions = $quiz['questions'];

        if ($currentIndex >= count($questions)) {
            return null;
        }

        return [
            'question' => $questions[$currentIndex],
            'currentIndex' => $currentIndex + 1,
            'totalQuestions' => count($questions),
            'categoryLabel' => $quiz['category_label'],
        ];
    }

    public function isActive(): bool
    {
        return $this->quiz() !== null;
    }

    public function hasCompleted(): bool
    {
        $quiz = $this->quiz();

        return $quiz !== null && $quiz['current_index'] >= count($quiz['questions']);
    }

    public function answer(?string $answer): void
    {
        $quiz = $this->quiz();

        if (! $quiz) {
            throw new QuizException('Quiz session not found.');
        }

        $currentIndex = $quiz['current_index'];

        if ($currentIndex >= count($quiz['questions'])) {
            return;
        }

        $question = &$quiz['questions'][$currentIndex];
        $question['selected_answer'] = $answer;
        $question['is_correct'] = is_string($answer)
            && hash_equals($question['correct_answer'], $answer);

        $quiz['current_index']++;

        session()->put(self::SESSION_KEY, $quiz);
    }

    /**
     * @return array<string, mixed>|null
     */
    public function results(): ?array
    {
        $quiz = $this->quiz();

        if (! $quiz || $quiz['current_index'] < count($quiz['questions'])) {
            return null;
        }

        $questions = collect($quiz['questions']);
        $score = $questions->where('is_correct', true)->count();
        $total = $questions->count();
        $percentage = $total > 0 ? (int) round(($score / $total) * 100) : 0;
        $outcome = QuizOutcome::fromPercentage($percentage);

        return [
            'questions' => $questions,
            'score' => $score,
            'total' => $total,
            'percentage' => $percentage,
            'resultLabel' => $outcome->label(),
            'categoryLabel' => $quiz['category_label'],
        ];
    }

    public function reset(): void
    {
        $quiz = $this->quiz();

        if ($quiz && isset($quiz['category'])) {
            session()->flash('previous_category', $quiz['category']);
        }

        session()->forget(self::SESSION_KEY);
    }

    /**
     * @return array<string, mixed>|null
     */
    public function quiz(): ?array
    {
        $quiz = session()->get(self::SESSION_KEY);

        return is_array($quiz) ? $quiz : null;
    }

    /**
     * @param  array<int, array<string, mixed>>  $questions
     * @return Collection<int, array<string, mixed>>
     */
    private function buildQuestions(array $questions): Collection
    {
        return collect($questions)
            ->filter(static fn (array $question): bool => ($question['type'] ?? null) === 'text_choice')
            ->map(function (array $question): array {
                $options = collect([
                    $question['correctAnswer'],
                    ...($question['incorrectAnswers'] ?? []),
                ])->shuffle()->values()->all();

                return [
                    'id' => $question['id'],
                    'prompt' => Arr::get($question, 'question.text', 'Question unavailable'),
                    'options' => $options,
                    'correct_answer' => $question['correctAnswer'],
                    'selected_answer' => null,
                    'is_correct' => null,
                    'difficulty' => $question['difficulty'] ?? null,
                ];
            })
            ->values();
    }
}
