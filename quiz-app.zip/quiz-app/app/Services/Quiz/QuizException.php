<?php

namespace App\Services\Quiz;

use RuntimeException;

class QuizException extends RuntimeException
{
}
