$(function () {
    const $timer = $('[data-quiz-timer]');

    if (!$timer.length) {
        return;
    }

    const $output = $timer.find('[data-quiz-timer-output]');
    const $timeoutForm = $('[data-timeout-form]');
    const totalSeconds = parseInt($timer.data('seconds'), 10) || 30;
    let remaining = totalSeconds;
    let isFinished = false;

    function renderTimer() {
        const minutes = Math.floor(remaining / 60);
        const seconds = String(remaining % 60).padStart(2, '0');
        $output.text(minutes + ':' + seconds);
    }

    function finishTimer() {
        if (isFinished) {
            return;
        }

        isFinished = true;
        window.clearInterval(intervalId);

        if ($timeoutForm.length) {
            $timeoutForm.trigger('submit');
        }
    }

    renderTimer();

    const intervalId = window.setInterval(function () {
        remaining -= 1;

        if (remaining <= 0) {
            remaining = 0;
            renderTimer();
            finishTimer();
            return;
        }

        renderTimer();
    }, 1000);

    $('form').on('submit', function () {
        if (isFinished) {
            return;
        }

        isFinished = true;
        window.clearInterval(intervalId);
    });
});
