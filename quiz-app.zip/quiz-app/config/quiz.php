<?php

return [
    'question_count' => env('QUIZ_QUESTION_COUNT', 50),
];