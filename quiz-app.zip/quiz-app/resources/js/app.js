<script>
$(document).ready(function () {

    const timer = $('[data-quiz-timer]');

    if (timer.length === 0) {
        return;
    }

    let seconds = parseInt(timer.data('seconds')) || 30;
    const output = timer.find('[data-quiz-timer-output]');
    const form = $('[data-timeout-form]');

    if (output.length === 0 || isNaN(seconds)) {
        return;
    }

    let remaining = seconds;

    function render() {
        let mins = Math.floor(remaining / 60);
        let secs = String(remaining % 60).padStart(2, '0');
        output.text(mins + ':' + secs);
    }

    render();

    let interval = setInterval(function () {
        remaining--;
        render();

        if (remaining > 0) return;

        clearInterval(interval);

        if (form.length) {
            $.ajax({
                url: form.attr('action'),
                type: form.attr('method') || 'POST',
                data: form.serialize(),

                success: function (response) {
                    // Example: redirect or update UI
                    if (response.redirect) {
                        window.location.href = response.redirect;
                    } else {
                        console.log('Quiz auto-submitted');
                    }
                },

                error: function () {
                    alert('Something went wrong while submitting quiz.');
                }
            });
        }

    }, 1000);

});
</script>