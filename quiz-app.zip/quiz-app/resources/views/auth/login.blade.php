<x-layouts.app :title="'Online Quiz - Login'">
    <section class="quiz-auth-page">
        <div class="quiz-login-wrap">
            <!-- <h1 class="quiz-login-title">Online Quiz - Login</h1> -->

            <div class="quiz-login-card">
                <div class="quiz-login-card-header">
                    <h2>Login</h2>
                </div>

                <div class="quiz-login-card-body">
                    <form method="POST" action="{{ route('login.attempt') }}">
                        @csrf

                        <div class="quiz-field">
                            <label for="email">Username</label>
                            <input
                                id="email"
                                name="email"
                                type="email"
                                value="{{ old('email') }}"
                                required
                                autofocus
                                class="quiz-input-line"
                                placeholder="Username"
                            >
                        </div>

                        <div class="quiz-field">
                            <label for="password">Password</label>
                            <input
                                id="password"
                                name="password"
                                type="password"
                                required
                                class="quiz-input-line"
                                placeholder="Password"
                            >
                        </div>

                        <span class="quiz-forgot">Forgot Password?</span>

                        <button type="submit" class="quiz-primary-btn">Login</button>
                    </form>

                    <div class="quiz-auth-footer">
                        Not a member?
                        <a href="{{ route('register') }}">Signup</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
</x-layouts.app>
