<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>{{ $title ?? 'Online Quiz' }}</title>
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=dm-sans:400,500,700|space-grotesk:400,500,700" rel="stylesheet" />
        <link rel="stylesheet" href="{{ asset('css/quiz.css') }}">
        <script src="https://code.jquery.com/jquery-3.7.1.min.js" crossorigin="anonymous"></script>
        <script src="{{ asset('js/quiz.js') }}" defer></script>
        @if (file_exists(public_path('build/manifest.json')) || file_exists(public_path('hot')))
            @vite(['resources/css/app.css', 'resources/js/app.js'])
        @endif
    </head>
    <body class="{{ trim((auth()->check() ? 'quiz-authenticated' : 'quiz-guest').' '.($bodyClass ?? '')) }}">
        <main class="quiz-shell">
            <div class="quiz-stage">
                @auth
                    <div class="quiz-topbar">
                        <div class="quiz-topbar-copy">
                            <p class="quiz-topbar-title">Online Quiz</p>
                            <p class="quiz-topbar-subtitle">Welcome back, {{ auth()->user()->name }}</p>
                        </div>
                        <form method="POST" action="{{ route('logout') }}">
                            @csrf
                            <button type="submit" class="quiz-topbar-btn">Logout</button>
                        </form>
                    </div>
                @endauth

                @if ($errors->any())
                    <div class="quiz-alert">
                        @foreach ($errors->all() as $error)
                            <p>{{ $error }}</p>
                        @endforeach
                    </div>
                @endif

                {{ $slot }}
            </div>
        </main>
    </body>
</html>
