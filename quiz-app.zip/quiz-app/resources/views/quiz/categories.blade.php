<x-layouts.app :title="'Online Quiz - Select Quiz Type'">
    @php
        $categoryPages = collect($categories)->chunk(6)->values();
        $dotCount = max(3, $categoryPages->count());

        $activePageIndex = 0;
        $previousCategory = session('previous_category');

        if ($previousCategory) {
            foreach ($categoryPages as $pageIndex => $pageCategories) {
                if (isset($pageCategories[$previousCategory])) {
                    $activePageIndex = $pageIndex;
                    break;
                }
            }
        }
    @endphp

    <section class="quiz-category-page">
        <!-- <h1 class="quiz-page-title">Online Quiz</h1> -->
        <p class="quiz-page-subtitle">Select Quiz Type</p>

        <div class="quiz-category-slider" data-category-slider>
            @foreach ($categoryPages as $pageIndex => $pageCategories)
                <div class="quiz-category-page-set {{ $pageIndex === $activePageIndex ? 'is-active' : '' }}" data-category-page="{{ $pageIndex }}">
                    <div class="quiz-category-grid">
                        @foreach ($pageCategories as $value => $label)
                            <form method="POST" action="{{ route('quiz.start') }}">
                                @csrf
                                <input type="hidden" name="category" value="{{ $value }}">
                                <button type="submit" class="quiz-category-pill">{{ $label }}</button>
                            </form>
                        @endforeach
                    </div>
                </div>
            @endforeach
        </div>

        @if ($dotCount > 0)
            <div class="quiz-category-dots" data-category-dots>
                @for ($pageIndex = 0; $pageIndex < $dotCount; $pageIndex++)
                    <button
                        type="button"
                        class="quiz-category-dot {{ $pageIndex === $activePageIndex ? 'is-active' : '' }} {{ $pageIndex >= $categoryPages->count() ? 'is-placeholder' : '' }}"
                        data-category-dot="{{ $pageIndex }}"
                        aria-label="Show category page {{ $pageIndex + 1 }}"
                        {{ $pageIndex >= $categoryPages->count() ? 'disabled' : '' }}
                    ></button>
                @endfor
            </div>
        @endif
    </section>

    <script>
        $(function () {
            const $pages = $('[data-category-page]');
            const $dots = $('[data-category-dot]');

            if ($pages.length <= 1) {
                return;
            }

            function showPage(pageIndex) {
                $pages.removeClass('is-active').hide();
                $dots.removeClass('is-active');

                $pages.filter('[data-category-page="' + pageIndex + '"]').addClass('is-active').fadeIn(180);
                $dots.filter('[data-category-dot="' + pageIndex + '"]').addClass('is-active');
            }

            $pages.not('.is-active').hide();

            $dots.on('click', function () {
                showPage($(this).data('categoryDot'));
            });
        });
    </script>
</x-layouts.app>
