<x-layouts.app :title="'Online Quiz - Question '.$currentIndex">
    <section class="quiz-play-page">
        <div class="quiz-play-top">
            <div class="quiz-play-meta">
                <a href="{{ route('quiz.categories') }}" class="quiz-step-badge">{{ $currentIndex }}</a>
                <div class="quiz-step-copy">
                    <p class="quiz-step-label">{{ $categoryLabel }}</p>
                    <p class="quiz-step-count">Question {{ $currentIndex }} of {{ $totalQuestions }}</p>
                </div>
            </div>

            <div data-quiz-timer data-seconds="30" class="quiz-timer-box">
                <p data-quiz-timer-output class="quiz-timer-value">0:30</p>
            </div>
        </div>

        <div class="quiz-question-card">{{ $question['prompt'] }}</div>

        <div class="quiz-answer-grid">
            @foreach ($question['options'] as $option)
                <form method="POST" action="{{ route('quiz.answer') }}">
                    @csrf
                    <input type="hidden" name="answer" value="{{ $option }}">
                    <button type="submit" class="quiz-answer-option">{{ $option }}</button>
                </form>
            @endforeach
        </div>

        <div class="quiz-play-actions">
            <form method="POST" action="{{ route('quiz.reset') }}">
                @csrf
                <button type="submit" class="quiz-primary-small-btn">Reset</button>
            </form>

            <form method="POST" action="{{ route('quiz.answer') }}" data-timeout-form>
                @csrf
                <button type="submit" class="quiz-secondary-btn">Skip</button>
            </form>
        </div>

        <div class="quiz-progress">
            <div class="quiz-progress-bar" style="width: {{ ($currentIndex / $totalQuestions) * 100 }}%"></div>
        </div>
    </section>
</x-layouts.app>
