<x-layouts.app :title="'Online Quiz - Results'">
    <section class="quiz-results-page">
        <h1 class="quiz-page-title">Results</h1>
        <p class="quiz-page-note">Category: {{ $categoryLabel }}. You scored {{ $score }} out of {{ $total }} ({{ $percentage }}%).</p>

        <div class="quiz-results-list">
            @foreach ($questions as $index => $question)
                <div class="quiz-results-row">
                    <div class="quiz-results-question">
                        {{ $question['prompt'] }}
                    </div>

                    <div class="quiz-results-answer {{ $question['is_correct'] ? 'is-correct' : 'is-wrong' }}">
                        <p class="quiz-results-answer-label">
                            {{ $question['is_correct'] ? 'Correct' : 'Correct Answer' }}
                        </p>
                        <p class="quiz-results-answer-main">{{ $question['correct_answer'] }}</p>
                        @if (! $question['is_correct'])
                            <p class="quiz-results-answer-sub">
                                Your answer:
                                {{ $question['selected_answer'] ?: 'Not answered' }}
                            </p>
                        @endif
                    </div>
                </div>
            @endforeach
        </div>

        <div class="quiz-results-winner">
            <p class="quiz-results-winner-label">Final Result</p>
            <p class="quiz-results-winner-value">{{ $resultLabel }}</p>
        </div>

        <div class="quiz-results-actions">
            <form method="POST" action="{{ route('quiz.reset') }}">
                @csrf
                <button type="submit" class="quiz-primary-small-btn">Play Again</button>
            </form>

            <a href="{{ route('quiz.categories') }}" class="quiz-secondary-btn">Choose Category</a>
        </div>
    </section>
</x-layouts.app>
