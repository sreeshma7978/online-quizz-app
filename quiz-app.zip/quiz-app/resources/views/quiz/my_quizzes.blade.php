<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Trivia Quizzes</title>

    <!-- Tailwind -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body class="bg-gray-100 p-8">

<div class="max-w-2xl mx-auto bg-white p-6 rounded shadow">
    <h1 class="text-2xl font-bold mb-4">My Quizzes</h1>

    <div id="quizzes-container" class="text-gray-600">
        Loading quizzes...
    </div>
</div>

<script>
$(document).ready(function () {

    $.ajax({
        url: '/api/my-quizzes',
        type: 'GET',
        dataType: 'json',

        success: function (data) {
            const container = $('#quizzes-container');
            container.html(''); // clear loading

            if (data.error) {
                container.html(`<p class="text-red-500">${data.error}</p>`);
                return;
            }

            if (data.length === 0) {
                container.html('<p>No quizzes found.</p>');
                return;
            }

            let list = $('<ul class="space-y-3"></ul>');

            $.each(data, function (index, quiz) {
                let item = `
                    <li class="p-4 bg-gray-50 border rounded">
                        <strong class="text-lg">${quiz.title}</strong><br>
                        <span class="text-sm text-gray-500">
                            ID: ${quiz.id} | ${quiz.questions ? quiz.questions.length : 0} Questions
                        </span>
                    </li>
                `;
                list.append(item);
            });

            container.append(list);
        },

        error: function () {
            $('#quizzes-container').html(
                '<p class="text-red-500">A network error occurred while loading quizzes.</p>'
            );
        }
    });

});
</script>

</body>
</html>