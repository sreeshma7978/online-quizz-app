<?php

use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\QuizController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return auth()->check()
        ? redirect()->route('quiz.categories')
        : redirect()->route('login');
});

Route::middleware('guest')->group(function (): void {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])
        ->middleware('throttle:auth-login')
        ->name('login.attempt');
    Route::get('/signup', [AuthController::class, 'showRegister'])->name('register');
    Route::post('/signup', [AuthController::class, 'register'])
        ->middleware('throttle:auth-register')
        ->name('register.store');
});

Route::middleware('auth')->group(function (): void {
    Route::post('/logout', [AuthController::class, 'logout'])
        ->middleware('throttle:quiz-actions')
        ->name('logout');

    Route::get('/quiz/categories', [QuizController::class, 'categories'])->name('quiz.categories');
    Route::post('/quiz/start', [QuizController::class, 'start'])
        ->middleware('throttle:quiz-actions')
        ->name('quiz.start');
    Route::get('/quiz/play', [QuizController::class, 'play'])->name('quiz.play');
    Route::post('/quiz/answer', [QuizController::class, 'answer'])
        ->middleware('throttle:quiz-actions')
        ->name('quiz.answer');
    Route::get('/quiz/results', [QuizController::class, 'results'])->name('quiz.results');
    Route::post('/quiz/reset', [QuizController::class, 'reset'])
        ->middleware('throttle:quiz-actions')
        ->name('quiz.reset');
});
